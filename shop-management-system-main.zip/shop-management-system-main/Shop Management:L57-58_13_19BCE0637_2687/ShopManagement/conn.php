<?php
$conn = mysqli_connect("localhost","root","","dbmsfinal");
//var_dump($conn);
?>
