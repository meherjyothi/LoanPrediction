# shop-management-system
## How to run the project
STEP 1-Open XAMPP. <br/>
STEP 2- Start Apache and MySQL. <br/>
STEP 3- Store the 'ShopManagement' folder under htdocs ( C:/xampp/htdocs for Windows and opt/lampp/htdocs for Linux ) <br/>
STEP 4- Click on 'Admin' for MySQL in XAMPP application, and check your default browser, it will have opened up 'localhost/phpmyadmin'. <br/>
STEP 5- At the left side, click on 'New', name the database 'dbmsfinal'. <br/>
STEP 6- Click on import at the top center, and select this file 'dbmsprojectdata.sql'. <br/>
STEP 7- Wait for it to load all the tables. <br/>
STEP 8- Go to your default browser and type in 'localhost/ShopManagement' <br/>
